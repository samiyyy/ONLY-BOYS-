export interface CustomSection {
  id: string;
  title: string;
  description: string;
  icon: string; // icon name from lucide
  items: CriteriaItem[];
}

export interface JobCriteria {
  id: string;
  jobTitle: string;
  department: string;
  qualifications: CriteriaItem[];
  education: CriteriaItem[];
  skills: CriteriaItem[];
  languages: CriteriaItem[];
  introduction: CriteriaConfig;
  certificates: CriteriaItem[];
  awards: CriteriaItem[];
  hobbies: CriteriaItem[];
  customSections: CustomSection[];
  createdAt: Date;
  updatedAt: Date;
}

export interface CriteriaItem {
  id: string;
  name: string;
  required: boolean;
  weight: number; // 1-10
}

export interface CriteriaConfig {
  required: boolean;
  weight: number;
  minLength?: number;
  keywords?: string[];
}

export interface ResumeAnalysis {
  id: string;
  candidateName: string;
  imageUrl: string;
  overallScore: number;
  recommendation: 'highly_recommended' | 'recommended' | 'consider' | 'not_recommended';
  scores: {
    qualifications: ScoreDetail;
    education: ScoreDetail;
    skills: ScoreDetail;
    languages: ScoreDetail;
    introduction: ScoreDetail;
    certificates: ScoreDetail;
    awards: ScoreDetail;
    hobbies: ScoreDetail;
  };
  matchedCriteria: string[];
  missingCriteria: string[];
  suggestions: string[];
  analyzedAt: Date;
}

export interface ScoreDetail {
  score: number;
  maxScore: number;
  percentage: number;
  matched: string[];
  missing: string[];
}

export interface AnalysisResult {
  resume: ResumeAnalysis;
  criteriaUsed: JobCriteria;
}
