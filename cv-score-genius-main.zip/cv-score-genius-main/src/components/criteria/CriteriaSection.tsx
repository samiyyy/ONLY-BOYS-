import { useState } from 'react';
import { Plus, Trash2, GripVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { CriteriaItem } from '@/types/resume';
import { generateId } from '@/lib/criteria-store';
import { cn } from '@/lib/utils';

interface CriteriaSectionProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  items: CriteriaItem[];
  onChange: (items: CriteriaItem[]) => void;
}

export function CriteriaSection({ title, description, icon, items, onChange }: CriteriaSectionProps) {
  const [newItemName, setNewItemName] = useState('');

  const addItem = () => {
    if (!newItemName.trim()) return;
    
    const newItem: CriteriaItem = {
      id: generateId(),
      name: newItemName.trim(),
      required: false,
      weight: 5,
    };
    
    onChange([...items, newItem]);
    setNewItemName('');
  };

  const updateItem = (id: string, updates: Partial<CriteriaItem>) => {
    onChange(items.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ));
  };

  const removeItem = (id: string) => {
    onChange(items.filter(item => item.id !== id));
  };

  return (
    <div className="bg-card rounded-2xl border border-border/50 shadow-card overflow-hidden animate-scale-in">
      <div className="p-6 border-b border-border/50 bg-gradient-card">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-primary/10 text-primary">
            {icon}
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">{title}</h3>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-4">
        {items.map((item, index) => (
          <div
            key={item.id}
            className={cn(
              "group flex items-center gap-4 p-4 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors",
            )}
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />
            
            <div className="flex-1 min-w-0">
              <Input
                value={item.name}
                onChange={(e) => updateItem(item.id, { name: e.target.value })}
                className="bg-background/50 border-border/50"
              />
            </div>

            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground whitespace-nowrap">Required</span>
                <Switch
                  checked={item.required}
                  onCheckedChange={(checked) => updateItem(item.id, { required: checked })}
                />
              </div>

              <div className="flex items-center gap-3 min-w-[140px]">
                <span className="text-xs text-muted-foreground">Weight</span>
                <Slider
                  value={[item.weight]}
                  onValueChange={([value]) => updateItem(item.id, { weight: value })}
                  min={1}
                  max={10}
                  step={1}
                  className="w-20"
                />
                <span className="text-sm font-medium text-foreground w-6">{item.weight}</span>
              </div>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => removeItem(item.id)}
                className="opacity-0 group-hover:opacity-100 text-destructive hover:text-destructive hover:bg-destructive/10"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}

        <div className="flex items-center gap-3 pt-2">
          <Input
            placeholder="Add new criteria..."
            value={newItemName}
            onChange={(e) => setNewItemName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addItem()}
            className="flex-1"
          />
          <Button onClick={addItem} disabled={!newItemName.trim()}>
            <Plus className="w-4 h-4 mr-2" />
            Add
          </Button>
        </div>
      </div>
    </div>
  );
}
