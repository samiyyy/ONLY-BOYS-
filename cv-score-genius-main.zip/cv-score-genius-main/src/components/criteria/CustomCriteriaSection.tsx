import { useState } from 'react';
import { Plus, Trash2, GripVertical, Pencil, Layers, Target, Users, Lightbulb, Star, Bookmark, Flag, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { CustomSection, CriteriaItem } from '@/types/resume';
import { generateId } from '@/lib/criteria-store';
import { cn } from '@/lib/utils';

interface CustomCriteriaSectionProps {
  section: CustomSection;
  onChange: (section: CustomSection) => void;
  onDelete: () => void;
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Layers,
  Target,
  Users,
  Lightbulb,
  Star,
  Bookmark,
  Flag,
  Zap,
};

export function CustomCriteriaSection({ section, onChange, onDelete }: CustomCriteriaSectionProps) {
  const [newItemName, setNewItemName] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(section.title);

  const IconComponent = iconMap[section.icon] || Layers;

  const addItem = () => {
    if (!newItemName.trim()) return;

    const newItem: CriteriaItem = {
      id: generateId(),
      name: newItemName.trim(),
      required: false,
      weight: 5,
    };

    onChange({
      ...section,
      items: [...section.items, newItem],
    });
    setNewItemName('');
  };

  const updateItem = (id: string, updates: Partial<CriteriaItem>) => {
    onChange({
      ...section,
      items: section.items.map(item =>
        item.id === id ? { ...item, ...updates } : item
      ),
    });
  };

  const removeItem = (id: string) => {
    onChange({
      ...section,
      items: section.items.filter(item => item.id !== id),
    });
  };

  const saveTitle = () => {
    if (editTitle.trim()) {
      onChange({ ...section, title: editTitle.trim() });
    }
    setIsEditing(false);
  };

  return (
    <div className="bg-card rounded-2xl border border-primary/30 shadow-card overflow-hidden animate-scale-in">
      <div className="p-6 border-b border-border/50 bg-gradient-to-r from-primary/10 to-accent/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/20 text-primary">
              <IconComponent className="w-5 h-5" />
            </div>
            <div>
              {isEditing ? (
                <Input
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  onBlur={saveTitle}
                  onKeyDown={(e) => e.key === 'Enter' && saveTitle()}
                  className="h-7 text-lg font-semibold"
                  autoFocus
                />
              ) : (
                <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
                  {section.title}
                  <span className="text-xs px-2 py-0.5 rounded-full bg-primary/20 text-primary font-medium">
                    Custom
                  </span>
                </h3>
              )}
              <p className="text-sm text-muted-foreground">{section.description}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsEditing(true)}
              className="text-muted-foreground hover:text-foreground"
            >
              <Pencil className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={onDelete}
              className="text-destructive hover:text-destructive hover:bg-destructive/10"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-4">
        {section.items.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Layers className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>No criteria added yet</p>
            <p className="text-sm">Add your first criterion below</p>
          </div>
        ) : (
          section.items.map((item, index) => (
            <div
              key={item.id}
              className={cn(
                "group flex items-center gap-4 p-4 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors"
              )}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />

              <div className="flex-1 min-w-0">
                <Input
                  value={item.name}
                  onChange={(e) => updateItem(item.id, { name: e.target.value })}
                  className="bg-background/50 border-border/50"
                />
              </div>

              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground whitespace-nowrap">Required</span>
                  <Switch
                    checked={item.required}
                    onCheckedChange={(checked) => updateItem(item.id, { required: checked })}
                  />
                </div>

                <div className="flex items-center gap-3 min-w-[140px]">
                  <span className="text-xs text-muted-foreground">Weight</span>
                  <Slider
                    value={[item.weight]}
                    onValueChange={([value]) => updateItem(item.id, { weight: value })}
                    min={1}
                    max={10}
                    step={1}
                    className="w-20"
                  />
                  <span className="text-sm font-medium text-foreground w-6">{item.weight}</span>
                </div>

                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeItem(item.id)}
                  className="opacity-0 group-hover:opacity-100 text-destructive hover:text-destructive hover:bg-destructive/10"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))
        )}

        <div className="flex items-center gap-3 pt-2">
          <Input
            placeholder="Add new criteria..."
            value={newItemName}
            onChange={(e) => setNewItemName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addItem()}
            className="flex-1"
          />
          <Button onClick={addItem} disabled={!newItemName.trim()}>
            <Plus className="w-4 h-4 mr-2" />
            Add
          </Button>
        </div>
      </div>
    </div>
  );
}
