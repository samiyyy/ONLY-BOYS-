import { useState } from 'react';
import { Plus, FolderPlus, X, Layers, Target, Users, Lightbulb, Star, Bookmark, Flag, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { CustomSection } from '@/types/resume';
import { generateId } from '@/lib/criteria-store';
import { cn } from '@/lib/utils';

interface AddCustomSectionProps {
  onAdd: (section: CustomSection) => void;
}

const availableIcons = [
  { name: 'Layers', icon: Layers },
  { name: 'Target', icon: Target },
  { name: 'Users', icon: Users },
  { name: 'Lightbulb', icon: Lightbulb },
  { name: 'Star', icon: Star },
  { name: 'Bookmark', icon: Bookmark },
  { name: 'Flag', icon: Flag },
  { name: 'Zap', icon: Zap },
];

export function AddCustomSection({ onAdd }: AddCustomSectionProps) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('Layers');

  const handleAdd = () => {
    if (!title.trim()) return;

    const newSection: CustomSection = {
      id: generateId(),
      title: title.trim(),
      description: description.trim() || `Custom criteria for ${title}`,
      icon: selectedIcon,
      items: [],
    };

    onAdd(newSection);
    setTitle('');
    setDescription('');
    setSelectedIcon('Layers');
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="lg" className="w-full border-dashed border-2 h-24 hover:border-primary hover:bg-primary/5">
          <FolderPlus className="w-6 h-6 mr-3" />
          <div className="text-left">
            <div className="font-semibold">Add Custom Section</div>
            <div className="text-sm text-muted-foreground">Create your own criteria category</div>
          </div>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FolderPlus className="w-5 h-5 text-primary" />
            Create Custom Section
          </DialogTitle>
          <DialogDescription>
            Add a new criteria category with custom items
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="section-title">Section Title *</Label>
            <Input
              id="section-title"
              placeholder="e.g., Projects, References, Soft Skills"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="section-description">Description</Label>
            <Textarea
              id="section-description"
              placeholder="Describe what this section evaluates..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label>Select Icon</Label>
            <div className="grid grid-cols-4 gap-2">
              {availableIcons.map(({ name, icon: Icon }) => (
                <button
                  key={name}
                  type="button"
                  onClick={() => setSelectedIcon(name)}
                  className={cn(
                    "p-3 rounded-lg border-2 transition-all hover:border-primary/50",
                    selectedIcon === name
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-secondary/50"
                  )}
                >
                  <Icon className="w-5 h-5 mx-auto" />
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleAdd} disabled={!title.trim()}>
            <Plus className="w-4 h-4 mr-2" />
            Create Section
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
