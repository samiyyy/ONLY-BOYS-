import { useState, useCallback } from 'react';
import { Upload, X, Image, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  accept?: string;
  maxSize?: number;
}

export function FileUpload({ onFileSelect, accept = "image/*", maxSize = 10 * 1024 * 1024 }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFile = useCallback((file: File) => {
    setError(null);

    if (file.size > maxSize) {
      setError(`File size must be less than ${maxSize / 1024 / 1024}MB`);
      return;
    }

    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file');
      return;
    }

    setFileName(file.name);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    onFileSelect(file);
  }, [maxSize, onFileSelect]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const clearFile = useCallback(() => {
    setPreview(null);
    setFileName(null);
    setError(null);
  }, []);

  return (
    <div className="w-full">
      {!preview ? (
        <label
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          className={cn(
            "flex flex-col items-center justify-center w-full h-80 border-2 border-dashed rounded-2xl cursor-pointer transition-all duration-300",
            isDragging
              ? "border-primary bg-primary/5 scale-[1.02]"
              : "border-border hover:border-primary/50 hover:bg-secondary/50",
            error && "border-destructive bg-destructive/5"
          )}
        >
          <div className="flex flex-col items-center justify-center pt-5 pb-6">
            <div className={cn(
              "p-4 rounded-2xl mb-4 transition-colors",
              isDragging ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"
            )}>
              <Upload className="w-10 h-10" />
            </div>
            <p className="mb-2 text-lg font-medium text-foreground">
              {isDragging ? "Drop your resume here" : "Upload Resume Image"}
            </p>
            <p className="text-sm text-muted-foreground">
              Drag and drop or click to browse
            </p>
            <p className="mt-2 text-xs text-muted-foreground">
              PNG, JPG, WEBP up to 10MB
            </p>
          </div>
          <input
            type="file"
            className="hidden"
            accept={accept}
            onChange={handleInputChange}
          />
        </label>
      ) : (
        <div className="relative w-full rounded-2xl overflow-hidden border border-border bg-card animate-scale-in">
          <div className="aspect-[3/4] max-h-[500px] overflow-hidden">
            <img
              src={preview}
              alt="Resume preview"
              className="w-full h-full object-contain bg-muted/50"
            />
          </div>
          <div className="absolute top-4 right-4 flex gap-2">
            <Button
              variant="glass"
              size="icon"
              onClick={clearFile}
              className="rounded-full"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="p-4 border-t border-border/50 bg-card/80 backdrop-blur-sm">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10 text-primary">
                <Image className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">{fileName}</p>
                <p className="text-xs text-muted-foreground">Ready for analysis</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {error && (
        <p className="mt-3 text-sm text-destructive text-center animate-fade-in">{error}</p>
      )}
    </div>
  );
}
