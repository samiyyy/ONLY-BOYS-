import { Download, Trash2, ChevronDown, ChevronUp, User, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ScoreRing } from '@/components/dashboard/ScoreRing';
import { ResumeAnalysis } from '@/types/resume';
import { cn } from '@/lib/utils';

interface ResultCardProps {
  result: ResumeAnalysis;
  onDelete: (id: string) => void;
  onDownload: (result: ResumeAnalysis) => void;
}

export function ResultCard({ result, onDelete, onDownload }: ResultCardProps) {
  const [expanded, setExpanded] = useState(false);

  const getRecommendationConfig = () => {
    switch (result.recommendation) {
      case 'highly_recommended':
        return { label: 'Highly Recommended', color: 'bg-success text-success-foreground', icon: CheckCircle };
      case 'recommended':
        return { label: 'Recommended', color: 'bg-primary text-primary-foreground', icon: CheckCircle };
      case 'consider':
        return { label: 'Consider', color: 'bg-warning text-warning-foreground', icon: AlertCircle };
      case 'not_recommended':
        return { label: 'Not Recommended', color: 'bg-destructive text-destructive-foreground', icon: XCircle };
    }
  };

  const recConfig = getRecommendationConfig();
  const RecIcon = recConfig.icon;

  const scoreCategories = [
    { key: 'qualifications', label: 'Qualifications' },
    { key: 'education', label: 'Education' },
    { key: 'skills', label: 'Skills' },
    { key: 'languages', label: 'Languages' },
    { key: 'introduction', label: 'Introduction' },
    { key: 'certificates', label: 'Certificates' },
    { key: 'awards', label: 'Awards' },
    { key: 'hobbies', label: 'Hobbies' },
  ] as const;

  return (
    <div className="bg-card rounded-2xl border border-border/50 shadow-card overflow-hidden animate-scale-in">
      <div className="p-6">
        <div className="flex flex-col md:flex-row md:items-center gap-6">
          <div className="flex items-center gap-4 flex-1">
            <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center overflow-hidden">
              {result.imageUrl ? (
                <img src={result.imageUrl} alt={result.candidateName} className="w-full h-full object-cover" />
              ) : (
                <User className="w-8 h-8 text-muted-foreground" />
              )}
            </div>
            <div>
              <h3 className="text-xl font-semibold text-foreground">{result.candidateName}</h3>
              <div className="flex items-center gap-2 mt-1">
                <span className={cn("inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium", recConfig.color)}>
                  <RecIcon className="w-3 h-3" />
                  {recConfig.label}
                </span>
                <span className="text-xs text-muted-foreground">
                  {new Date(result.analyzedAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <ScoreRing score={result.overallScore} size="md" label="Overall" />
            
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={() => onDownload(result)}>
                <Download className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={() => onDelete(result.id)} className="text-destructive hover:text-destructive hover:bg-destructive/10">
                <Trash2 className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => setExpanded(!expanded)}>
                {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {expanded && (
        <div className="px-6 pb-6 pt-0 space-y-6 animate-slide-up">
          <div className="h-px bg-border" />
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {scoreCategories.map(({ key, label }) => (
              <div key={key} className="text-center p-4 rounded-xl bg-secondary/50">
                <ScoreRing score={result.scores[key].percentage} size="sm" showLabel={false} />
                <p className="mt-2 text-xs font-medium text-muted-foreground">{label}</p>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-success/10 border border-success/20">
              <h4 className="text-sm font-semibold text-success mb-3 flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Matched Criteria ({result.matchedCriteria.length})
              </h4>
              <ul className="space-y-1">
                {result.matchedCriteria.slice(0, 5).map((item, i) => (
                  <li key={i} className="text-sm text-foreground">{item}</li>
                ))}
                {result.matchedCriteria.length > 5 && (
                  <li className="text-sm text-muted-foreground">+{result.matchedCriteria.length - 5} more</li>
                )}
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-destructive/10 border border-destructive/20">
              <h4 className="text-sm font-semibold text-destructive mb-3 flex items-center gap-2">
                <XCircle className="w-4 h-4" />
                Missing Criteria ({result.missingCriteria.length})
              </h4>
              <ul className="space-y-1">
                {result.missingCriteria.slice(0, 5).map((item, i) => (
                  <li key={i} className="text-sm text-foreground">{item}</li>
                ))}
                {result.missingCriteria.length > 5 && (
                  <li className="text-sm text-muted-foreground">+{result.missingCriteria.length - 5} more</li>
                )}
              </ul>
            </div>
          </div>

          {result.suggestions.length > 0 && (
            <div className="p-4 rounded-xl bg-info/10 border border-info/20">
              <h4 className="text-sm font-semibold text-info mb-3">Suggestions</h4>
              <ul className="space-y-2">
                {result.suggestions.map((suggestion, i) => (
                  <li key={i} className="text-sm text-foreground flex items-start gap-2">
                    <span className="text-info">•</span>
                    {suggestion}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
