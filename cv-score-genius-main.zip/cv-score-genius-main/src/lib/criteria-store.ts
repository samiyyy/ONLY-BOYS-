import { JobCriteria, CriteriaItem, CustomSection } from '@/types/resume';

const STORAGE_KEY = 'resume-analyzer-criteria';

export const defaultCriteria: JobCriteria = {
  id: 'default',
  jobTitle: 'Software Engineer',
  department: 'Engineering',
  qualifications: [
    { id: '1', name: '3+ years experience', required: true, weight: 9 },
    { id: '2', name: 'Problem solving skills', required: true, weight: 8 },
    { id: '3', name: 'Team collaboration', required: false, weight: 6 },
  ],
  education: [
    { id: '1', name: "Bachelor's in Computer Science", required: true, weight: 8 },
    { id: '2', name: "Master's degree", required: false, weight: 5 },
  ],
  skills: [
    { id: '1', name: 'JavaScript/TypeScript', required: true, weight: 9 },
    { id: '2', name: 'React', required: true, weight: 9 },
    { id: '3', name: 'Node.js', required: false, weight: 7 },
    { id: '4', name: 'SQL/NoSQL', required: false, weight: 6 },
    { id: '5', name: 'Git', required: true, weight: 7 },
  ],
  languages: [
    { id: '1', name: 'English (Fluent)', required: true, weight: 10 },
    { id: '2', name: 'Spanish', required: false, weight: 3 },
  ],
  introduction: {
    required: true,
    weight: 5,
    minLength: 100,
    keywords: ['passionate', 'innovative', 'team player'],
  },
  certificates: [
    { id: '1', name: 'AWS Certified', required: false, weight: 6 },
    { id: '2', name: 'Google Cloud', required: false, weight: 5 },
  ],
  awards: [
    { id: '1', name: 'Any professional award', required: false, weight: 4 },
  ],
  hobbies: [
    { id: '1', name: 'Tech-related hobbies', required: false, weight: 2 },
    { id: '2', name: 'Team sports', required: false, weight: 2 },
  ],
  customSections: [],
  createdAt: new Date(),
  updatedAt: new Date(),
};

export function getCriteria(): JobCriteria {
  if (typeof window === 'undefined') return defaultCriteria;
  
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      return {
        ...parsed,
        createdAt: new Date(parsed.createdAt),
        updatedAt: new Date(parsed.updatedAt),
      };
    } catch {
      return defaultCriteria;
    }
  }
  return defaultCriteria;
}

export function saveCriteria(criteria: JobCriteria): void {
  criteria.updatedAt = new Date();
  localStorage.setItem(STORAGE_KEY, JSON.stringify(criteria));
}

export function resetCriteria(): JobCriteria {
  localStorage.removeItem(STORAGE_KEY);
  return defaultCriteria;
}

export function generateId(): string {
  return Math.random().toString(36).substr(2, 9);
}
