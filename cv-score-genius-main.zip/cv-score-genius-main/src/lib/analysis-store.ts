import { ResumeAnalysis } from '@/types/resume';

const STORAGE_KEY = 'resume-analyzer-results';

export function getAnalysisResults(): ResumeAnalysis[] {
  if (typeof window === 'undefined') return [];
  
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      return parsed.map((r: ResumeAnalysis) => ({
        ...r,
        analyzedAt: new Date(r.analyzedAt),
      }));
    } catch {
      return [];
    }
  }
  return [];
}

export function saveAnalysisResult(result: ResumeAnalysis): void {
  const results = getAnalysisResults();
  results.unshift(result);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(results.slice(0, 50)));
}

export function deleteAnalysisResult(id: string): void {
  const results = getAnalysisResults();
  const filtered = results.filter(r => r.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
}

export function clearAllResults(): void {
  localStorage.removeItem(STORAGE_KEY);
}
