import { useState, useEffect } from 'react';
import { Download, Trash2, Search, Filter, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PageLayout } from '@/components/layout/PageLayout';
import { ResultCard } from '@/components/results/ResultCard';
import { getAnalysisResults, deleteAnalysisResult, clearAllResults } from '@/lib/analysis-store';
import { ResumeAnalysis } from '@/types/resume';
import { toast } from '@/hooks/use-toast';

const ResultsPage = () => {
  const [results, setResults] = useState<ResumeAnalysis[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRecommendation, setFilterRecommendation] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('date');

  useEffect(() => {
    setResults(getAnalysisResults());
  }, []);

  const handleDelete = (id: string) => {
    deleteAnalysisResult(id);
    setResults(prev => prev.filter(r => r.id !== id));
    toast({
      title: "Result Deleted",
      description: "The analysis result has been removed.",
    });
  };

  const handleClearAll = () => {
    clearAllResults();
    setResults([]);
    toast({
      title: "All Results Cleared",
      description: "All analysis results have been removed.",
    });
  };

  const handleDownload = (result: ResumeAnalysis) => {
    const reportContent = generateReportContent(result);
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${result.candidateName.replace(/\s+/g, '_')}_analysis_report.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Report Downloaded",
      description: `Analysis report for ${result.candidateName} has been downloaded.`,
    });
  };

  const handleDownloadAll = () => {
    const allReports = filteredResults.map(result => generateReportContent(result)).join('\n\n' + '='.repeat(80) + '\n\n');
    const blob = new Blob([allReports], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `all_resume_analysis_reports.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "All Reports Downloaded",
      description: `${filteredResults.length} analysis reports have been downloaded.`,
    });
  };

  const generateReportContent = (result: ResumeAnalysis): string => {
    const lines = [
      `RESUME ANALYSIS REPORT`,
      `${'='.repeat(50)}`,
      ``,
      `Candidate: ${result.candidateName}`,
      `Analysis Date: ${new Date(result.analyzedAt).toLocaleDateString()}`,
      `Overall Score: ${result.overallScore}%`,
      `Recommendation: ${result.recommendation.replace('_', ' ').toUpperCase()}`,
      ``,
      `CATEGORY SCORES`,
      `${'-'.repeat(30)}`,
      `Qualifications: ${result.scores.qualifications.percentage}%`,
      `Education: ${result.scores.education.percentage}%`,
      `Skills: ${result.scores.skills.percentage}%`,
      `Languages: ${result.scores.languages.percentage}%`,
      `Introduction: ${result.scores.introduction.percentage}%`,
      `Certificates: ${result.scores.certificates.percentage}%`,
      `Awards: ${result.scores.awards.percentage}%`,
      `Hobbies: ${result.scores.hobbies.percentage}%`,
      ``,
      `MATCHED CRITERIA`,
      `${'-'.repeat(30)}`,
      ...result.matchedCriteria.map(c => `✓ ${c}`),
      ``,
      `MISSING CRITERIA`,
      `${'-'.repeat(30)}`,
      ...result.missingCriteria.map(c => `✗ ${c}`),
      ``,
      `SUGGESTIONS`,
      `${'-'.repeat(30)}`,
      ...result.suggestions.map(s => `• ${s}`),
    ];
    return lines.join('\n');
  };

  const filteredResults = results
    .filter(r => {
      const matchesSearch = r.candidateName.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesFilter = filterRecommendation === 'all' || r.recommendation === filterRecommendation;
      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'score-high':
          return b.overallScore - a.overallScore;
        case 'score-low':
          return a.overallScore - b.overallScore;
        case 'name':
          return a.candidateName.localeCompare(b.candidateName);
        case 'date':
        default:
          return new Date(b.analyzedAt).getTime() - new Date(a.analyzedAt).getTime();
      }
    });

  return (
    <PageLayout
      title="Analysis Results"
      description="View and manage all resume analysis results. Download reports or compare candidates."
    >
      {/* Filters */}
      <div className="bg-card rounded-2xl border border-border/50 shadow-card p-4 mb-8 animate-scale-in">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search candidates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={filterRecommendation} onValueChange={setFilterRecommendation}>
            <SelectTrigger className="w-full md:w-[200px]">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Results</SelectItem>
              <SelectItem value="highly_recommended">Highly Recommended</SelectItem>
              <SelectItem value="recommended">Recommended</SelectItem>
              <SelectItem value="consider">Consider</SelectItem>
              <SelectItem value="not_recommended">Not Recommended</SelectItem>
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full md:w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Date (Newest)</SelectItem>
              <SelectItem value="score-high">Score (High to Low)</SelectItem>
              <SelectItem value="score-low">Score (Low to High)</SelectItem>
              <SelectItem value="name">Name (A-Z)</SelectItem>
            </SelectContent>
          </Select>

          {results.length > 0 && (
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleDownloadAll}>
                <Download className="w-4 h-4 mr-2" />
                Download All
              </Button>
              <Button variant="outline" onClick={handleClearAll} className="text-destructive hover:text-destructive hover:bg-destructive/10">
                <Trash2 className="w-4 h-4 mr-2" />
                Clear All
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Results List */}
      {filteredResults.length > 0 ? (
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Showing {filteredResults.length} of {results.length} results
          </p>
          {filteredResults.map((result, index) => (
            <div key={result.id} style={{ animationDelay: `${index * 50}ms` }}>
              <ResultCard
                result={result}
                onDelete={handleDelete}
                onDownload={handleDownload}
              />
            </div>
          ))}
        </div>
      ) : results.length === 0 ? (
        <div className="text-center py-20 animate-fade-in">
          <div className="p-6 rounded-full bg-secondary w-fit mx-auto mb-6">
            <FileText className="w-12 h-12 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-semibold text-foreground mb-2">No Results Yet</h3>
          <p className="text-muted-foreground max-w-md mx-auto">
            You haven't analyzed any resumes yet. Upload a resume to get started with AI-powered analysis.
          </p>
          <Button className="mt-6" onClick={() => window.location.href = '/analyze'}>
            Analyze Your First Resume
          </Button>
        </div>
      ) : (
        <div className="text-center py-20 animate-fade-in">
          <div className="p-6 rounded-full bg-secondary w-fit mx-auto mb-6">
            <Search className="w-12 h-12 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-semibold text-foreground mb-2">No Matching Results</h3>
          <p className="text-muted-foreground">
            No results match your current filters. Try adjusting your search criteria.
          </p>
        </div>
      )}
    </PageLayout>
  );
};

export default ResultsPage;
