import { Link } from 'react-router-dom';
import { Upload, Settings, BarChart3, Sparkles, ArrowRight, CheckCircle, Brain, Shield, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageLayout } from '@/components/layout/PageLayout';
import { StatsCard } from '@/components/dashboard/StatsCard';
import { getAnalysisResults } from '@/lib/analysis-store';
import { getCriteria } from '@/lib/criteria-store';

const Index = () => {
  const results = getAnalysisResults();
  const criteria = getCriteria();
  
  const totalAnalyzed = results.length;
  const avgScore = results.length > 0 
    ? Math.round(results.reduce((sum, r) => sum + r.overallScore, 0) / results.length)
    : 0;
  const recommended = results.filter(r => r.recommendation === 'highly_recommended' || r.recommendation === 'recommended').length;

  const features = [
    {
      icon: Brain,
      title: 'AI-Powered Analysis',
      description: 'Advanced algorithms analyze resumes against your custom criteria with precision.',
    },
    {
      icon: Settings,
      title: 'Customizable Rules',
      description: 'Define and adjust job requirements, skills, and qualifications to match your needs.',
    },
    {
      icon: Shield,
      title: 'Comprehensive Scoring',
      description: 'Get detailed scores across 8 categories including skills, education, and experience.',
    },
    {
      icon: Zap,
      title: 'Instant Results',
      description: 'Upload and receive detailed analysis reports in seconds, ready to download.',
    },
  ];

  return (
    <PageLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-hero p-8 md:p-12 mb-12">
        <div className="absolute inset-0 bg-gradient-glow opacity-50" />
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-foreground/10 backdrop-blur-sm border border-primary-foreground/20 text-primary-foreground text-sm font-medium mb-6 animate-fade-in">
            <Sparkles className="w-4 h-4" />
            AI-Powered Resume Screening
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-6 animate-slide-up">
            Find the Perfect
            <span className="block text-accent">Candidates</span>
          </h1>
          <p className="text-lg md:text-xl text-primary-foreground/80 mb-8 animate-slide-up" style={{ animationDelay: '100ms' }}>
            Upload resume images and let our AI analyze them against your custom job criteria. 
            Get instant scores, recommendations, and downloadable reports.
          </p>
          <div className="flex flex-wrap gap-4 animate-slide-up" style={{ animationDelay: '200ms' }}>
            <Link to="/analyze">
              <Button variant="hero" size="xl">
                <Upload className="w-5 h-5" />
                Analyze Resume
              </Button>
            </Link>
            <Link to="/criteria">
              <Button variant="glass" size="xl" className="text-primary-foreground border-primary-foreground/30">
                <Settings className="w-5 h-5" />
                Setup Criteria
              </Button>
            </Link>
          </div>
        </div>
        <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-accent/20 rounded-full blur-3xl" />
        <div className="absolute right-20 top-10 w-40 h-40 bg-primary-foreground/10 rounded-full blur-2xl animate-float" />
      </section>

      {/* Stats Section */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <StatsCard
          title="Resumes Analyzed"
          value={totalAnalyzed}
          icon={<BarChart3 className="w-6 h-6" />}
          delay={0}
        />
        <StatsCard
          title="Average Score"
          value={`${avgScore}%`}
          icon={<Sparkles className="w-6 h-6" />}
          delay={100}
        />
        <StatsCard
          title="Recommended"
          value={recommended}
          icon={<CheckCircle className="w-6 h-6" />}
          delay={200}
        />
      </section>

      {/* Current Criteria Quick View */}
      <section className="bg-card rounded-2xl border border-border/50 shadow-card p-6 mb-12 animate-scale-in">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Current Job Criteria</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Position: {criteria.jobTitle} • {criteria.department}
            </p>
          </div>
          <Link to="/criteria">
            <Button variant="outline">
              Edit Criteria
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-secondary/50">
            <p className="text-2xl font-bold text-foreground">{criteria.skills.length}</p>
            <p className="text-sm text-muted-foreground">Skills</p>
          </div>
          <div className="p-4 rounded-xl bg-secondary/50">
            <p className="text-2xl font-bold text-foreground">{criteria.qualifications.length}</p>
            <p className="text-sm text-muted-foreground">Qualifications</p>
          </div>
          <div className="p-4 rounded-xl bg-secondary/50">
            <p className="text-2xl font-bold text-foreground">{criteria.education.length}</p>
            <p className="text-sm text-muted-foreground">Education</p>
          </div>
          <div className="p-4 rounded-xl bg-secondary/50">
            <p className="text-2xl font-bold text-foreground">{criteria.certificates.length}</p>
            <p className="text-sm text-muted-foreground">Certificates</p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-foreground mb-8 text-center">Why Choose ResumeAI?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={feature.title}
                className="bg-card rounded-2xl border border-border/50 p-6 shadow-card hover:shadow-card-hover transition-all duration-300 animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="p-3 rounded-xl bg-primary/10 text-primary w-fit mb-4">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Quick Actions */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to="/criteria" className="group">
          <div className="h-full bg-card rounded-2xl border border-border/50 p-6 shadow-card hover:shadow-card-hover hover:border-primary/30 transition-all duration-300">
            <div className="p-3 rounded-xl bg-primary/10 text-primary w-fit mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
              <Settings className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Configure Criteria</h3>
            <p className="text-sm text-muted-foreground mb-4">Set up job requirements, skills, and qualifications for candidate evaluation.</p>
            <span className="text-sm font-medium text-primary flex items-center gap-2 group-hover:gap-3 transition-all">
              Get Started <ArrowRight className="w-4 h-4" />
            </span>
          </div>
        </Link>

        <Link to="/analyze" className="group">
          <div className="h-full bg-card rounded-2xl border border-border/50 p-6 shadow-card hover:shadow-card-hover hover:border-primary/30 transition-all duration-300">
            <div className="p-3 rounded-xl bg-accent/10 text-accent w-fit mb-4 group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
              <Upload className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Analyze Resume</h3>
            <p className="text-sm text-muted-foreground mb-4">Upload a resume image and get instant AI-powered analysis and scoring.</p>
            <span className="text-sm font-medium text-accent flex items-center gap-2 group-hover:gap-3 transition-all">
              Upload Now <ArrowRight className="w-4 h-4" />
            </span>
          </div>
        </Link>

        <Link to="/results" className="group">
          <div className="h-full bg-card rounded-2xl border border-border/50 p-6 shadow-card hover:shadow-card-hover hover:border-primary/30 transition-all duration-300">
            <div className="p-3 rounded-xl bg-success/10 text-success w-fit mb-4 group-hover:bg-success group-hover:text-success-foreground transition-colors">
              <BarChart3 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">View Results</h3>
            <p className="text-sm text-muted-foreground mb-4">Review all analyzed resumes, scores, and download detailed reports.</p>
            <span className="text-sm font-medium text-success flex items-center gap-2 group-hover:gap-3 transition-all">
              View All <ArrowRight className="w-4 h-4" />
            </span>
          </div>
        </Link>
      </section>
    </PageLayout>
  );
};

export default Index;
