import { useState, useEffect } from 'react';
import { Save, RotateCcw, Briefcase, GraduationCap, Wrench, Globe, FileText, Award, Medal, Heart, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PageLayout } from '@/components/layout/PageLayout';
import { CriteriaSection } from '@/components/criteria/CriteriaSection';
import { AddCustomSection } from '@/components/criteria/AddCustomSection';
import { CustomCriteriaSection } from '@/components/criteria/CustomCriteriaSection';
import { getCriteria, saveCriteria, resetCriteria, defaultCriteria } from '@/lib/criteria-store';
import { JobCriteria, CustomSection } from '@/types/resume';
import { toast } from '@/hooks/use-toast';

const CriteriaPage = () => {
  const [criteria, setCriteria] = useState<JobCriteria>(defaultCriteria);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    setCriteria(getCriteria());
  }, []);

  const handleSave = () => {
    saveCriteria(criteria);
    setHasChanges(false);
    toast({
      title: "Criteria Saved",
      description: "Your job criteria have been saved successfully.",
    });
  };

  const handleReset = () => {
    const reset = resetCriteria();
    setCriteria(reset);
    setHasChanges(false);
    toast({
      title: "Criteria Reset",
      description: "Job criteria have been reset to defaults.",
    });
  };

  const updateCriteria = <K extends keyof JobCriteria>(key: K, value: JobCriteria[K]) => {
    setCriteria(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const addCustomSection = (section: CustomSection) => {
    setCriteria(prev => ({
      ...prev,
      customSections: [...(prev.customSections || []), section],
    }));
    setHasChanges(true);
    toast({
      title: "Section Added",
      description: `"${section.title}" section has been created.`,
    });
  };

  const updateCustomSection = (index: number, section: CustomSection) => {
    setCriteria(prev => ({
      ...prev,
      customSections: prev.customSections.map((s, i) => (i === index ? section : s)),
    }));
    setHasChanges(true);
  };

  const deleteCustomSection = (index: number) => {
    const sectionName = criteria.customSections[index]?.title;
    setCriteria(prev => ({
      ...prev,
      customSections: prev.customSections.filter((_, i) => i !== index),
    }));
    setHasChanges(true);
    toast({
      title: "Section Deleted",
      description: `"${sectionName}" section has been removed.`,
    });
  };

  return (
    <PageLayout
      title="Job Criteria Setup"
      description="Define the requirements for candidate evaluation. All criteria are customizable with weight and priority settings."
    >
      {/* How Scoring Works Info Box */}
      <div className="bg-gradient-to-r from-primary/10 via-accent/10 to-primary/5 rounded-2xl border border-primary/20 p-6 mb-8 animate-scale-in">
        <div className="flex items-start gap-4">
          <div className="p-2 rounded-xl bg-primary/20 text-primary">
            <Info className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">How AI Scoring Works</h3>
            <div className="grid md:grid-cols-3 gap-4 text-sm text-muted-foreground">
              <div className="bg-background/50 rounded-lg p-3">
                <div className="font-medium text-foreground mb-1">1. Weight (1-10)</div>
                <p>Higher weight = more impact on final score. A skill with weight 10 affects the score 10x more than weight 1.</p>
              </div>
              <div className="bg-background/50 rounded-lg p-3">
                <div className="font-medium text-foreground mb-1">2. Required Toggle</div>
                <p>Required criteria MUST be present. Missing required items significantly reduce the match percentage.</p>
              </div>
              <div className="bg-background/50 rounded-lg p-3">
                <div className="font-medium text-foreground mb-1">3. Weighted Average</div>
                <p>Final score = (matched × weight) / (total weight). AI extracts text from resume and matches against your criteria.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Job Info Section */}
      <div className="bg-card rounded-2xl border border-border/50 shadow-card p-6 mb-8 animate-scale-in">
        <h3 className="text-lg font-semibold text-foreground mb-4">Job Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="jobTitle">Job Title</Label>
            <Input
              id="jobTitle"
              value={criteria.jobTitle}
              onChange={(e) => updateCriteria('jobTitle', e.target.value)}
              placeholder="e.g., Senior Software Engineer"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="department">Department</Label>
            <Input
              id="department"
              value={criteria.department}
              onChange={(e) => updateCriteria('department', e.target.value)}
              placeholder="e.g., Engineering"
            />
          </div>
        </div>
      </div>

      {/* Default Criteria Sections */}
      <div className="grid gap-8">
        <CriteriaSection
          title="Qualifications"
          description="Required experience and professional qualifications"
          icon={<Briefcase className="w-5 h-5" />}
          items={criteria.qualifications}
          onChange={(items) => updateCriteria('qualifications', items)}
        />

        <CriteriaSection
          title="Education"
          description="Educational requirements and degrees"
          icon={<GraduationCap className="w-5 h-5" />}
          items={criteria.education}
          onChange={(items) => updateCriteria('education', items)}
        />

        <CriteriaSection
          title="Skills"
          description="Technical and soft skills required for the position"
          icon={<Wrench className="w-5 h-5" />}
          items={criteria.skills}
          onChange={(items) => updateCriteria('skills', items)}
        />

        <CriteriaSection
          title="Languages"
          description="Language proficiency requirements"
          icon={<Globe className="w-5 h-5" />}
          items={criteria.languages}
          onChange={(items) => updateCriteria('languages', items)}
        />

        <CriteriaSection
          title="Certificates"
          description="Professional certifications and credentials"
          icon={<Award className="w-5 h-5" />}
          items={criteria.certificates}
          onChange={(items) => updateCriteria('certificates', items)}
        />

        <CriteriaSection
          title="Awards"
          description="Professional awards and recognitions"
          icon={<Medal className="w-5 h-5" />}
          items={criteria.awards}
          onChange={(items) => updateCriteria('awards', items)}
        />

        <CriteriaSection
          title="Hobbies & Interests"
          description="Relevant hobbies and personal interests"
          icon={<Heart className="w-5 h-5" />}
          items={criteria.hobbies}
          onChange={(items) => updateCriteria('hobbies', items)}
        />

        {/* Custom Sections */}
        {criteria.customSections?.map((section, index) => (
          <CustomCriteriaSection
            key={section.id}
            section={section}
            onChange={(updated) => updateCustomSection(index, updated)}
            onDelete={() => deleteCustomSection(index)}
          />
        ))}

        {/* Add Custom Section Button */}
        <AddCustomSection onAdd={addCustomSection} />
      </div>

      {/* Action Buttons */}
      <div className="sticky bottom-6 mt-8">
        <div className="bg-card/95 backdrop-blur-lg rounded-2xl border border-border/50 shadow-lg p-4 flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            {hasChanges ? (
              <span className="text-warning font-medium">You have unsaved changes</span>
            ) : (
              <span>Last updated: {criteria.updatedAt.toLocaleDateString()}</span>
            )}
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={handleReset}>
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset to Default
            </Button>
            <Button onClick={handleSave} disabled={!hasChanges}>
              <Save className="w-4 h-4 mr-2" />
              Save Criteria
            </Button>
          </div>
        </div>
      </div>
    </PageLayout>
  );
};

export default CriteriaPage;
