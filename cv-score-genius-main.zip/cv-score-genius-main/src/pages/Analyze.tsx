import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, Loader2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PageLayout } from '@/components/layout/PageLayout';
import { FileUpload } from '@/components/analyze/FileUpload';
import { getCriteria } from '@/lib/criteria-store';
import { saveAnalysisResult } from '@/lib/analysis-store';
import { ResumeAnalysis, JobCriteria, ScoreDetail } from '@/types/resume';
import { toast } from '@/hooks/use-toast';

function generateMockAnalysis(candidateName: string, imageUrl: string, criteria: JobCriteria): ResumeAnalysis {
  const generateScoreDetail = (items: { name: string; weight: number; required: boolean }[]): ScoreDetail => {
    const totalWeight = items.reduce((sum, item) => sum + item.weight, 0);
    const matchedCount = Math.floor(Math.random() * items.length) + 1;
    const matched = items.slice(0, matchedCount).map(i => i.name);
    const missing = items.slice(matchedCount).map(i => i.name);
    const score = matched.reduce((sum, name) => {
      const item = items.find(i => i.name === name);
      return sum + (item?.weight || 0);
    }, 0);
    
    return {
      score,
      maxScore: totalWeight,
      percentage: totalWeight > 0 ? Math.round((score / totalWeight) * 100) : 0,
      matched,
      missing,
    };
  };

  const scores = {
    qualifications: generateScoreDetail(criteria.qualifications),
    education: generateScoreDetail(criteria.education),
    skills: generateScoreDetail(criteria.skills),
    languages: generateScoreDetail(criteria.languages),
    introduction: {
      score: Math.floor(Math.random() * 10) + 1,
      maxScore: 10,
      percentage: Math.floor(Math.random() * 100),
      matched: ['Professional summary included'],
      missing: [],
    },
    certificates: generateScoreDetail(criteria.certificates),
    awards: generateScoreDetail(criteria.awards),
    hobbies: generateScoreDetail(criteria.hobbies),
  };

  const allScores = Object.values(scores);
  const overallScore = Math.round(
    allScores.reduce((sum, s) => sum + s.percentage, 0) / allScores.length
  );

  const recommendation = 
    overallScore >= 80 ? 'highly_recommended' :
    overallScore >= 60 ? 'recommended' :
    overallScore >= 40 ? 'consider' : 'not_recommended';

  const matchedCriteria = [
    ...scores.qualifications.matched,
    ...scores.skills.matched,
    ...scores.education.matched,
  ];

  const missingCriteria = [
    ...scores.qualifications.missing,
    ...scores.skills.missing,
    ...scores.education.missing,
  ];

  const suggestions = [
    overallScore < 60 && 'Consider candidates with more relevant experience',
    scores.skills.percentage < 50 && 'Technical skills could be improved',
    scores.education.percentage < 50 && 'Educational background may need verification',
    scores.certificates.percentage < 30 && 'Professional certifications would strengthen the profile',
  ].filter(Boolean) as string[];

  return {
    id: Math.random().toString(36).substr(2, 9),
    candidateName,
    imageUrl,
    overallScore,
    recommendation,
    scores,
    matchedCriteria,
    missingCriteria,
    suggestions,
    analyzedAt: new Date(),
  };
}

const AnalyzePage = () => {
  const navigate = useNavigate();
  const [file, setFile] = useState<File | null>(null);
  const [candidateName, setCandidateName] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const handleFileSelect = (selectedFile: File) => {
    setFile(selectedFile);
    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(selectedFile);
  };

  const handleAnalyze = async () => {
    if (!file || !candidateName.trim()) {
      toast({
        title: "Missing Information",
        description: "Please provide a candidate name and upload a resume image.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);

    // Simulate AI analysis
    await new Promise(resolve => setTimeout(resolve, 3000));

    const criteria = getCriteria();
    const result = generateMockAnalysis(candidateName.trim(), imagePreview || '', criteria);
    
    saveAnalysisResult(result);

    setIsAnalyzing(false);
    
    toast({
      title: "Analysis Complete",
      description: `${candidateName}'s resume has been analyzed. Score: ${result.overallScore}%`,
    });

    navigate('/results');
  };

  const criteria = getCriteria();

  return (
    <PageLayout
      title="Analyze Resume"
      description="Upload a resume image to analyze it against your job criteria."
    >
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Upload Section */}
        <div className="space-y-6">
          <div className="bg-card rounded-2xl border border-border/50 shadow-card p-6 animate-scale-in">
            <h3 className="text-lg font-semibold text-foreground mb-4">Resume Image</h3>
            <FileUpload onFileSelect={handleFileSelect} />
          </div>

          <div className="bg-card rounded-2xl border border-border/50 shadow-card p-6 animate-scale-in" style={{ animationDelay: '100ms' }}>
            <h3 className="text-lg font-semibold text-foreground mb-4">Candidate Information</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="candidateName">Candidate Name *</Label>
                <Input
                  id="candidateName"
                  value={candidateName}
                  onChange={(e) => setCandidateName(e.target.value)}
                  placeholder="Enter candidate's full name"
                />
              </div>
            </div>
          </div>

          <Button
            onClick={handleAnalyze}
            disabled={!file || !candidateName.trim() || isAnalyzing}
            size="xl"
            className="w-full"
            variant="hero"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Analyzing Resume...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Analyze Resume
              </>
            )}
          </Button>
        </div>

        {/* Criteria Preview */}
        <div className="space-y-6">
          <div className="bg-card rounded-2xl border border-border/50 shadow-card p-6 animate-scale-in" style={{ animationDelay: '200ms' }}>
            <h3 className="text-lg font-semibold text-foreground mb-2">Current Evaluation Criteria</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Position: {criteria.jobTitle} • {criteria.department}
            </p>

            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium text-foreground mb-2">Required Skills ({criteria.skills.filter(s => s.required).length})</h4>
                <div className="flex flex-wrap gap-2">
                  {criteria.skills.filter(s => s.required).map(skill => (
                    <span key={skill.id} className="px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
                      {skill.name}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-foreground mb-2">Preferred Skills ({criteria.skills.filter(s => !s.required).length})</h4>
                <div className="flex flex-wrap gap-2">
                  {criteria.skills.filter(s => !s.required).map(skill => (
                    <span key={skill.id} className="px-3 py-1 rounded-full bg-secondary text-secondary-foreground text-xs font-medium">
                      {skill.name}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-foreground mb-2">Education Requirements</h4>
                <ul className="space-y-1">
                  {criteria.education.map(edu => (
                    <li key={edu.id} className="text-sm text-muted-foreground flex items-center gap-2">
                      <span className={edu.required ? 'text-primary' : 'text-muted-foreground'}>•</span>
                      {edu.name}
                      {edu.required && <span className="text-xs text-primary">(Required)</span>}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="text-sm font-medium text-foreground mb-2">Qualifications</h4>
                <ul className="space-y-1">
                  {criteria.qualifications.map(qual => (
                    <li key={qual.id} className="text-sm text-muted-foreground flex items-center gap-2">
                      <span className={qual.required ? 'text-primary' : 'text-muted-foreground'}>•</span>
                      {qual.name}
                      {qual.required && <span className="text-xs text-primary">(Required)</span>}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-info/10 border border-info/20 rounded-2xl p-6 animate-scale-in" style={{ animationDelay: '300ms' }}>
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-info mt-0.5" />
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-1">How Analysis Works</h4>
                <p className="text-sm text-muted-foreground">
                  Our AI analyzes the uploaded resume image against your defined criteria. 
                  Each category is scored based on the weight and requirements you've set. 
                  The overall score reflects how well the candidate matches your job requirements.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  );
};

export default AnalyzePage;
